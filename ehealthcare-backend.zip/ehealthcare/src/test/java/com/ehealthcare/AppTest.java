package com.ehealthcare;

import com.ehealthcare.utils.PasswordUtil;
import com.ehealthcare.utils.ValidationUtil;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Unit tests for core utility classes.
 * Integration tests (DB-connected) should be run separately.
 */
public class AppTest {

    // --- PasswordUtil Tests ---

    @Test
    public void testPasswordHashAndVerify() {
        String plain = "SecurePass1";
        String hash = PasswordUtil.hash(plain);
        assertNotNull("Hash should not be null", hash);
        assertTrue("Hash should contain salt separator", hash.contains(":"));
        assertTrue("Correct password should verify", PasswordUtil.verify(plain, hash));
        assertFalse("Wrong password should not verify", PasswordUtil.verify("WrongPass9", hash));
    }

    @Test
    public void testPasswordHashesAreDifferent() {
        String plain = "SecurePass1";
        String hash1 = PasswordUtil.hash(plain);
        String hash2 = PasswordUtil.hash(plain);
        assertNotEquals("Two hashes of same password should differ (different salts)", hash1, hash2);
        assertTrue("Both should still verify correctly", PasswordUtil.verify(plain, hash1));
        assertTrue("Both should still verify correctly", PasswordUtil.verify(plain, hash2));
    }

    // --- ValidationUtil Tests ---

    @Test
    public void testEmailValidation() {
        assertTrue(ValidationUtil.isValidEmail("patient@example.com"));
        assertTrue(ValidationUtil.isValidEmail("dr.smith@hospital.org"));
        assertFalse(ValidationUtil.isValidEmail("notanemail"));
        assertFalse(ValidationUtil.isValidEmail("missing@tld"));
        assertFalse(ValidationUtil.isValidEmail(null));
    }

    @Test
    public void testPasswordValidation() {
        assertTrue(ValidationUtil.isValidPassword("Password1"));
        assertTrue(ValidationUtil.isValidPassword("abc12345"));
        assertFalse(ValidationUtil.isValidPassword("short1"));   // Too short
        assertFalse(ValidationUtil.isValidPassword("allletter")); // No digit
        assertFalse(ValidationUtil.isValidPassword("12345678"));  // No letter
        assertFalse(ValidationUtil.isValidPassword(null));
    }

    @Test
    public void testPhoneValidation() {
        assertTrue(ValidationUtil.isValidPhone("+2348012345678"));
        assertTrue(ValidationUtil.isValidPhone("08012345678"));
        assertFalse(ValidationUtil.isValidPhone("123"));
        assertFalse(ValidationUtil.isValidPhone(null));
    }

    @Test
    public void testIsNotBlank() {
        assertTrue(ValidationUtil.isNotBlank("hello"));
        assertFalse(ValidationUtil.isNotBlank(""));
        assertFalse(ValidationUtil.isNotBlank("   "));
        assertFalse(ValidationUtil.isNotBlank(null));
    }
}
